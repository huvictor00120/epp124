/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Clock, 
  CheckCircle2, 
  ChevronDown, 
  ArrowRight, 
  Menu, 
  X, 
  Brain, 
  Sparkles, 
  Coffee, 
  Heart,
  Instagram,
  Linkedin,
  GraduationCap,
  Briefcase,
  Stethoscope,
  School
} from 'lucide-react';

// --- Components ---

const SpeakerCard = ({ name, role, bio, instagram, linkedin, image }: { name: string, role: string, bio: string, instagram: string, linkedin: string, image: string }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    whileHover={{ y: -10 }}
    className="bg-white p-6 rounded-[2rem] shadow-sm border border-zinc-100 transition-all duration-300 hover:shadow-xl group"
  >
    <div className="aspect-square rounded-2xl overflow-hidden mb-6">
      <img src={image} alt={name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
    </div>
    <h3 className="text-xl font-bold mb-1">{name}</h3>
    <p className="text-brand-primary text-sm font-semibold mb-4 leading-tight">{role}</p>
    <p className="text-zinc-500 text-sm mb-6 leading-relaxed">{bio}</p>
    <div className="flex gap-4">
      <a 
        href={`https://instagram.com/${instagram}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-zinc-400 hover:text-brand-primary transition-all hover:scale-110 active:scale-95"
      >
        <Instagram size={20} />
      </a>
      <a 
        href={`https://linkedin.com/in/${linkedin}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-zinc-400 hover:text-brand-primary transition-all hover:scale-110 active:scale-95"
      >
        <Linkedin size={20} />
      </a>
    </div>
  </motion.div>
);

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'O Evento', href: '#sobre' },
    { name: 'Para Quem', href: '#publico' },
    { name: 'Palestrantes', href: '#palestrantes' },
    { name: 'Programação', href: '#programacao' },
    { name: 'Inscrição', href: '#inscricao' },
    { name: 'FAQ', href: '#faq' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass py-3 shadow-sm' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-brand-primary rounded-lg flex items-center justify-center text-white font-bold text-xl">E</div>
          <span className="font-display font-bold text-xl tracking-tighter">EPPA 2026</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a key={link.name} href={link.href} className="text-sm font-medium hover:text-brand-primary transition-colors">
              {link.name}
            </a>
          ))}
          <a href="#inscricao" className="bg-brand-primary text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:shadow-lg hover:scale-105 transition-all">
            Garantir Ingresso
          </a>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden p-2 rounded-lg hover:bg-zinc-100 transition-colors" 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-expanded={isMobileMenuOpen}
          aria-controls="mobile-menu"
          aria-label={isMobileMenuOpen ? "Fechar menu" : "Abrir menu"}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            id="mobile-menu"
            role="navigation"
            aria-label="Menu móvel"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 glass border-t border-zinc-200 p-6 flex flex-col gap-4 md:hidden"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-lg font-medium py-2 border-b border-zinc-100 focus:outline-none focus:text-brand-primary"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="#inscricao" 
              onClick={() => setIsMobileMenuOpen(false)} 
              className="bg-brand-primary text-white text-center py-4 rounded-xl font-bold mt-2 focus:ring-4 focus:ring-brand-primary/20 outline-none"
            >
              Garantir Ingresso
            </a>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const SectionHeading = ({ title, subtitle, centered = true }: { title: string, subtitle?: string, centered?: boolean }) => (
  <div className={`mb-12 ${centered ? 'text-center max-w-3xl mx-auto' : 'text-left'}`}>
    <motion.h2 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="text-3xl md:text-4xl font-bold mb-4"
    >
      {title}
    </motion.h2>
    {subtitle && (
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="text-zinc-600 text-lg leading-relaxed"
      >
        {subtitle}
      </motion.p>
    )}
  </div>
);

const FAQItem = ({ question, answer }: { question: string, answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-zinc-200 py-4">
      <button 
        className="w-full flex justify-between items-center text-left py-2 hover:text-brand-primary transition-colors"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-semibold text-lg">{question}</span>
        <ChevronDown className={`transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <p className="py-4 text-zinc-600 leading-relaxed">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen selection:bg-brand-primary selection:text-white">
      <Navbar />

      {/* SECTION 1: HERO */}
      <header className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        {/* Abstract Background Elements */}
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-brand-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-brand-secondary/10 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex flex-wrap gap-2 mb-6">
              <span className="bg-brand-primary/10 text-brand-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">21ª Edição</span>
              <span className="bg-zinc-100 text-zinc-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">100% Presencial</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-[1.1] mb-6">
              EPPA 2026: O maior encontro acadêmico de <span className="text-brand-primary">Publicidade e Propaganda</span> em Joinville
            </h1>
            
            <p className="text-xl text-zinc-600 mb-10 max-w-xl leading-relaxed">
              Um dia para desacelerar, pensar a comunicação com profundidade e resgatar o propósito da sua carreira.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <a href="#inscricao" className="bg-brand-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:shadow-xl hover:-translate-y-1 transition-all flex items-center justify-center gap-2">
                Garantir meu ingresso (1º lote)
                <ArrowRight size={20} />
              </a>
              <a href="#programacao" className="bg-white border border-zinc-200 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-zinc-50 transition-all flex items-center justify-center">
                Conhecer a experiência
              </a>
            </div>
            
            <div className="grid grid-cols-2 gap-6 border-t border-zinc-200 pt-8">
              <div className="flex items-center gap-3">
                <Calendar className="text-brand-primary" />
                <div>
                  <p className="text-xs font-bold uppercase text-zinc-400">Data</p>
                  <p className="font-semibold">22 de Agosto, 2026</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="text-brand-primary" />
                <div>
                  <p className="text-xs font-bold uppercase text-zinc-400">Local</p>
                  <p className="font-semibold">Joinville – SC</p>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl relative group">
              <img 
                src="https://picsum.photos/seed/eppa-event/800/1000" 
                alt="Estudantes de publicidade em Joinville reunidos em palestra sobre saúde mental no EPPA" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-8">
                <p className="text-white font-medium italic">"O EPPA foi decisivo para eu repensar minha carreira na comunicação sem culpa."</p>
              </div>
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -left-6 glass p-6 rounded-2xl shadow-xl max-w-[200px]">
              <p className="text-3xl font-bold text-brand-primary mb-1">+20</p>
              <p className="text-sm font-medium text-zinc-600 leading-tight">Edições formando gerações de comunicadores.</p>
            </div>
          </motion.div>
        </div>
      </header>

      {/* SPONSORS MARQUEE - MOVED TO TOP FOR SOCIAL PROOF */}
      <div className="relative flex overflow-x-hidden bg-zinc-50 py-10 border-y border-zinc-100">
        <div className="animate-marquee whitespace-nowrap flex items-center gap-16 px-8">
          {[
            "Patrocinador Alpha", "Criativa Labs", "Mídia+ Comunicação", "Insight Agency", 
            "Universo Digital", "Studio 360", "Nova Ideia Marketing",
            "Patrocinador Alpha", "Criativa Labs", "Mídia+ Comunicação", "Insight Agency", 
            "Universo Digital", "Studio 360", "Nova Ideia Marketing"
          ].map((name, i) => (
            <div key={i} className="flex items-center gap-4 group cursor-pointer">
              <div className="w-10 h-10 bg-zinc-200 rounded-lg group-hover:bg-brand-primary/20 transition-colors" />
              <span className="text-lg font-display font-bold text-zinc-400 group-hover:text-zinc-900 transition-colors">{name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: O QUE É O EPPA */}
      <section id="sobre" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <SectionHeading 
                title="O EPPA é o respiro que a comunicação precisa" 
                centered={false}
              />
              <p className="text-lg text-zinc-600 mb-8 leading-relaxed">
                Há 21 edições, o EPPA (Evento de Publicidade e Propaganda Acadêmico) é o ponto de encontro para quem quer discutir o futuro da área com calma e profundidade. 
              </p>
              <p className="text-lg text-zinc-600 mb-10 leading-relaxed">
                Fugimos do "hype" vazio e da correria para focar no que importa: saúde mental, criatividade sustentável e inovação com responsabilidade.
              </p>
              
              <div className="space-y-6">
                {[
                  { icon: <Brain className="text-brand-primary" />, title: "Conteúdo acadêmico conectado com a prática", text: "Teoria que faz sentido no dia a dia das agências e empresas." },
                  { icon: <Sparkles className="text-brand-secondary" />, title: "Networking sem pressão", text: "Espaços seguros para trocas genuínas entre estudantes e profissionais." },
                  { icon: <Coffee className="text-brand-accent" />, title: "Programação anti-burnout", text: "Um dia desenhado para te inspirar, não para te esgotar." }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex gap-4"
                  >
                    <div className="w-12 h-12 rounded-xl bg-zinc-50 flex items-center justify-center shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-lg mb-1">{item.title}</h4>
                      <p className="text-zinc-500">{item.text}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4 pt-12">
                <img src="https://picsum.photos/seed/eppa1/400/500" alt="Networking no EPPA" className="rounded-2xl w-full h-64 object-cover shadow-lg" referrerPolicy="no-referrer" />
                <img src="https://picsum.photos/seed/eppa2/400/300" alt="Palestra EPPA" className="rounded-2xl w-full h-48 object-cover shadow-lg" referrerPolicy="no-referrer" />
              </div>
              <div className="space-y-4">
                <img src="https://picsum.photos/seed/eppa3/400/300" alt="Workshop EPPA" className="rounded-2xl w-full h-48 object-cover shadow-lg" referrerPolicy="no-referrer" />
                <img src="https://picsum.photos/seed/eppa4/400/500" alt="Público EPPA" className="rounded-2xl w-full h-64 object-cover shadow-lg" referrerPolicy="no-referrer" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: EDIÇÕES ANTERIORES (PROVA SOCIAL) - MOVED UP AS SUGGESTED */}
      <section className="section-padding bg-zinc-900 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <SectionHeading 
            title="Mais de 20 edições formando gerações" 
            subtitle="O EPPA se consolidou como um dos mais importantes encontros acadêmicos de Publicidade e Propaganda do Brasil."
          />
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
            {[
              { label: "Edições Realizadas", value: "20+" },
              { label: "Participantes", value: "15k+" },
              { label: "Horas de Conteúdo", value: "500+" },
              { label: "Instituições", value: "40+" }
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <p className="text-4xl md:text-6xl font-bold text-brand-primary mb-2">{stat.value}</p>
                <p className="text-zinc-400 uppercase text-xs font-bold tracking-widest">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { text: "O EPPA foi decisivo para eu repensar minha carreira na comunicação sem culpa.", author: "Ana Silva", role: "Diretora de Arte" },
              { text: "Um evento que realmente se importa com o ser humano por trás do profissional.", author: "Lucas Santos", role: "Estudante de PP" },
              { text: "A melhor ponte entre o que aprendemos na faculdade e o que o mercado exige.", author: "Carla Oliveira", role: "Professora Universitária" }
            ].map((testimonial, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white/5 p-8 rounded-3xl border border-white/10"
              >
                <p className="text-lg italic mb-6 text-zinc-300">"{testimonial.text}"</p>
                <div>
                  <p className="font-bold">{testimonial.author}</p>
                  <p className="text-sm text-zinc-500">{testimonial.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4: PARA QUEM É */}
      <section id="publico" className="section-padding bg-bg-soft">
        <div className="max-w-7xl mx-auto">
          <SectionHeading 
            title="Feito para quem vive a comunicação" 
            subtitle="E sente que o ritmo atual está engolindo sua criatividade e saúde."
          />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { 
                icon: <GraduationCap className="text-brand-primary" />, 
                title: "Estudantes", 
                text: "Prepare-se para o mercado sem romantizar a exaustão. Conecte teoria e prática com cases reais." 
              },
              { 
                icon: <Briefcase className="text-brand-secondary" />, 
                title: "Profissionais", 
                text: "Reflita sobre limites saudáveis e atualize-se sem a pressão dos 'cases do ano'." 
              },
              { 
                icon: <Stethoscope className="text-brand-accent" />, 
                title: "Área da Saúde", 
                text: "Explore a interface entre comportamento, saúde mental e o mercado criativo." 
              },
              { 
                icon: <School className="text-brand-primary" />, 
                title: "Docentes", 
                text: "Leve discussões reais para a sala de aula e conecte seus alunos com o mercado." 
              }
            ].map((card, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-8 rounded-3xl shadow-sm border border-zinc-100"
              >
                <div className="w-14 h-14 rounded-2xl bg-zinc-50 flex items-center justify-center mb-6">
                  {card.icon}
                </div>
                <h3 className="text-xl font-bold mb-4">{card.title}</h3>
                <p className="text-zinc-600 leading-relaxed">{card.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4: PALESTRANTES */}
      <section id="palestrantes" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <SectionHeading 
            title="Palestrantes que vão provocar reflexões sem esgotar você" 
            subtitle="O EPPA 2026 reúne nomes da academia, do mercado e da área da saúde para conversar sobre comunicação, carreira e bem-estar com profundidade."
          />
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <SpeakerCard 
              name="Ana Ribeiro"
              role="Estrategista de Marca & Professora"
              bio="Especialista em branding e construção de narrativas para marcas, com foco em propósito, consistência e impacto social."
              instagram="anaribeiro_estrategia"
              linkedin="anaribeiro"
              image="https://picsum.photos/seed/ana/400/400"
            />
            <SpeakerCard 
              name="Lucas Martins"
              role="Diretor de Criação em Agência Digital"
              bio="Atua na liderança de equipes criativas, promovendo processos de criação mais humanos, colaborativos e sustentáveis."
              instagram="lucasmartins.cria"
              linkedin="lucasmartins"
              image="https://picsum.photos/seed/lucas/400/400"
            />
            <SpeakerCard 
              name="Dra. Juliana Costa"
              role="Psicóloga, pesquisadora em burnout e trabalho criativo"
              bio="Pesquisa exaustão profissional em áreas criativas e trabalha com estratégias de prevenção e cuidado."
              instagram="dra.julianacosta"
              linkedin="julianacosta"
              image="https://picsum.photos/seed/juliana/400/400"
            />
            <SpeakerCard 
              name="Rafael Oliveira"
              role="Head de Estratégia em Marketing Digital"
              bio="Conecta dados, cultura e comportamento do consumidor para criar estratégias consistentes sem sacrificar a saúde."
              instagram="rafa.oliveira.estrategia"
              linkedin="rafaeloliveira"
              image="https://picsum.photos/seed/rafael/400/400"
            />
            <SpeakerCard 
              name="Profª Marina Souza"
              role="Docente em Publicidade e Propaganda"
              bio="Professora universitária, mentora de estudantes e pesquisadora em ensino de comunicação e práticas inovadoras."
              instagram="profmarinasouza"
              linkedin="marinasouza"
              image="https://picsum.photos/seed/marina/400/400"
            />
            <SpeakerCard 
              name="Diego Lima"
              role="Planner em agência e criador de conteúdo"
              bio="Une planejamento estratégico e criação de conteúdo sobre bastidores reais da comunicação e rotina de agência."
              instagram="diegolimacom"
              linkedin="diegolima"
              image="https://picsum.photos/seed/diego/400/400"
            />
          </div>
          
          <p className="text-center text-zinc-400 text-xs mt-12 italic">
            *Palestrantes sujeitos a alteração. Lista completa será divulgada próximo ao evento.
          </p>
        </div>
      </section>

      {/* SECTION 5: A EXPERIÊNCIA EM 1 DIA (PROGRAMAÇÃO) */}
      <section id="programacao" className="section-padding bg-zinc-50">
        <div className="max-w-7xl mx-auto">
          <SectionHeading 
            title="Um cronograma desenhado para o seu fôlego" 
            subtitle="Um dia intenso, mas equilibrado. Aprenda, conecte-se e respire."
          />
          
          <div className="space-y-12 max-w-4xl mx-auto">
            {[
              { 
                time: "Manhã", 
                title: "Despertar e Refletir", 
                items: ["Abertura e boas-vindas", "Palestra Magna: Saúde Mental e Futuro da Comunicação", "Mesa: Como equilibrar entrega e bem-estar"] 
              },
              { 
                time: "Tarde", 
                title: "Aprofundar e Praticar", 
                items: ["Workshops práticos (Criação, Estratégia, Autogestão)", "Rodas de conversa sobre novos modelos de trabalho", "Feira de agências e projetos acadêmicos"] 
              },
              { 
                time: "Noite", 
                title: "Celebrar e Conectar", 
                items: ["Palestra de encerramento inspiradora", "Intervenções artísticas e Pocket Show", "Espaço de networking e confraternização"] 
              }
            ].map((period, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="relative pl-12 border-l-2 border-zinc-200"
              >
                <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-brand-primary border-4 border-white" />
                <span className="text-brand-primary font-bold uppercase tracking-widest text-sm mb-2 block">{period.time}</span>
                <h3 className="text-2xl font-bold mb-6">{period.title}</h3>
                <ul className="space-y-4">
                  {period.items.map((item, j) => (
                    <li key={j} className="flex items-center gap-3 text-zinc-600">
                      <CheckCircle2 size={18} className="text-brand-accent" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <p className="text-zinc-500 italic mb-8">Programação completa em breve – garanta seu ingresso no 1º lote e receba as atualizações.</p>
            <a href="#inscricao" className="inline-flex items-center gap-2 text-brand-primary font-bold hover:underline">
              Ver detalhes da inscrição <ArrowRight size={16} />
            </a>
          </div>
        </div>
      </section>

      {/* SECTION 7: INFORMAÇÕES PRÁTICAS + INSCRIÇÃO */}
      <section id="inscricao" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <SectionHeading 
                title="Garanta seu lugar na 21ª edição" 
                subtitle="1º lote com valores especiais de lançamento. Vagas limitadas para garantir a qualidade da experiência."
                centered={false}
              />
              
              <div className="space-y-8 mb-12">
                <div className="flex gap-4 p-6 rounded-2xl border border-zinc-100 bg-zinc-50">
                  <Calendar className="text-brand-primary shrink-0" />
                  <div>
                    <p className="font-bold">22 de Agosto de 2026</p>
                    <p className="text-zinc-500">Sábado, das 08h às 21h</p>
                  </div>
                </div>
                <div className="flex gap-4 p-6 rounded-2xl border border-zinc-100 bg-zinc-50">
                  <MapPin className="text-brand-primary shrink-0" />
                  <div>
                    <p className="font-bold">Joinville – SC</p>
                    <p className="text-zinc-500">Local a ser divulgado em breve</p>
                  </div>
                </div>
                <div className="flex gap-4 p-6 rounded-2xl border border-zinc-100 bg-zinc-50">
                  <Users className="text-brand-primary shrink-0" />
                  <div>
                    <p className="font-bold">Público</p>
                    <p className="text-zinc-500">Estudantes, Egressos, Profissionais e Área da Saúde</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="glass p-10 rounded-[2rem] shadow-2xl relative">
              <div className="absolute -top-4 -right-4 bg-brand-accent text-white px-4 py-2 rounded-xl font-bold text-sm rotate-3">
                1º LOTE ABERTO
              </div>
              
              <h3 className="text-2xl font-bold mb-8">Escolha seu ingresso</h3>
              
              <div className="space-y-4 mb-10">
                <div className="flex justify-between items-center p-6 rounded-2xl border-2 border-brand-primary bg-brand-primary/5">
                  <div>
                    <p className="font-bold text-lg">Estudante</p>
                    <p className="text-xs text-zinc-500 uppercase font-bold">Mediante comprovação</p>
                  </div>
                  <p className="text-2xl font-bold text-brand-primary">R$ 89,90</p>
                </div>
                <div className="flex justify-between items-center p-6 rounded-2xl border border-zinc-200 hover:border-brand-primary transition-colors cursor-pointer">
                  <div>
                    <p className="font-bold text-lg">Profissional / Egresso</p>
                    <p className="text-xs text-zinc-500 uppercase font-bold">Valor promocional</p>
                  </div>
                  <p className="text-2xl font-bold">R$ 149,90</p>
                </div>
                <div className="flex justify-between items-center p-6 rounded-2xl border border-zinc-200 hover:border-brand-primary transition-colors cursor-pointer">
                  <div>
                    <p className="font-bold text-lg">Grupos (5+ pessoas)</p>
                    <p className="text-xs text-zinc-500 uppercase font-bold">Valor por pessoa</p>
                  </div>
                  <p className="text-2xl font-bold text-brand-accent">R$ 79,90</p>
                </div>
              </div>
              
              <button className="w-full bg-brand-primary text-white py-5 rounded-2xl font-bold text-xl shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all mb-6">
                Fazer minha inscrição agora
              </button>
              
              <div className="flex items-center justify-center gap-2 text-zinc-400 text-sm">
                <Clock size={16} />
                <span>Pagamento seguro via Infinity Pay</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 8: GRUPOS, PROFESSORES E INSTITUIÇÕES */}
      <section className="section-padding bg-bg-soft">
        <div className="max-w-7xl mx-auto">
          <SectionHeading 
            title="Grupos, professores e instituições" 
            subtitle="Condições especiais para fortalecer a relação entre universidade e mercado."
          />
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "Grupos e Caravanas", text: "Descontos progressivos para grupos a partir de 5 participantes. Apoio total da nossa equipe." },
              { title: "Professores", text: "Condições especiais para docentes que trazem turmas. Certificado com carga horária para atividades." },
              { title: "Instituições", text: "Pacotes institucionais e cotas de participação para apresentar projetos e cursos na feira." }
            ].map((card, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-zinc-100">
                <h4 className="text-xl font-bold mb-4">{card.title}</h4>
                <p className="text-zinc-600 mb-8">{card.text}</p>
                <button className="text-brand-primary font-bold flex items-center gap-2 hover:gap-3 transition-all">
                  Solicitar condições <ArrowRight size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 9: PATROCINADORES E PARCEIROS */}
      <section className="section-padding bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <SectionHeading 
            title="Seja parceiro do maior evento acadêmico de Publicidade e Propaganda do Brasil" 
            subtitle="O EPPA conecta sua marca diretamente a estudantes, egressos, professores e profissionais de comunicação."
            centered={true}
          />
        </div>
          
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 text-left mb-16">
            {[
              "Presença em materiais de divulgação do evento",
              "Ativação de marca em feira e estandes",
              "Contato direto com talentos e profissionais",
              "Associação a inovação, ética e saúde mental"
            ].map((benefit, i) => (
              <div key={i} className="flex gap-3">
                <CheckCircle2 className="text-brand-accent shrink-0" size={20} />
                <p className="text-sm font-medium text-zinc-600">{benefit}</p>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button className="bg-zinc-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-zinc-800 transition-all hover:shadow-lg">
              Receber mídia kit e oportunidades de cota
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 10: FAQ */}
      <section id="faq" className="section-padding bg-zinc-50">
        <div className="max-w-3xl mx-auto">
          <SectionHeading title="Perguntas frequentes" />
          <div className="space-y-2">
            <FAQItem 
              question="O EPPA é aberto para qualquer curso?" 
              answer="Sim! Embora o foco seja Publicidade e Propaganda, o evento é aberto a estudantes e profissionais de Jornalismo, Design, RP, Marketing e também da área da saúde (como Psicologia)." 
            />
            <FAQItem 
              question="Vai ter certificado de participação?" 
              answer="Sim. Todos os participantes recebem certificado digital com carga horária após o evento." 
            />
            <FAQItem 
              question="Como funcionam os descontos para grupos?" 
              answer="Grupos a partir de 5 pessoas têm valores reduzidos. Entre em contato com nossa equipe para receber o link de pagamento exclusivo para o seu grupo." 
            />
            <FAQItem 
              question="O evento será transmitido online?" 
              answer="Não. O EPPA 2026 será 100% presencial em Joinville – SC, para favorecer a imersão e o networking real." 
            />
            <FAQItem 
              question="Onde será o local exato?" 
              answer="O local está sendo finalizado e será divulgado em breve. Todos os inscritos receberão as informações por e-mail." 
            />
          </div>
        </div>
      </section>

      {/* SECTION 11: CTA FINAL */}
      <section className="section-padding bg-brand-primary text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -mr-48 -mt-48" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-black/10 rounded-full blur-3xl -ml-48 -mb-48" />
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-bold mb-8">Menos correria, mais profundidade. Vamos juntos?</h2>
          <p className="text-xl text-white/80 mb-12 leading-relaxed">
            Se o ritmo da área parece pesado, o EPPA é o seu ponto de pausa. Recupere o fôlego e a inspiração em um dia inesquecível em Joinville.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#inscricao" className="bg-white text-brand-primary px-10 py-5 rounded-2xl font-bold text-xl hover:shadow-2xl hover:-translate-y-1 transition-all">
              Garantir meu ingresso no 1º lote
            </a>
            <button className="bg-transparent border-2 border-white/30 text-white px-10 py-5 rounded-2xl font-bold text-xl hover:bg-white/10 transition-all">
              Receber novidades
            </button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-12 px-6 border-t border-zinc-200 bg-white">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-primary rounded-lg flex items-center justify-center text-white font-bold">E</div>
            <span className="font-display font-bold text-lg tracking-tighter">EPPA 2026</span>
          </div>
          
          <p className="text-zinc-400 text-sm">© 2026 EPPA – Evento Acadêmico de Publicidade e Propaganda. Todos os direitos reservados.</p>
          
          <div className="flex gap-6">
            <a href="#" className="text-zinc-400 hover:text-brand-primary transition-colors">Instagram</a>
            <a href="#" className="text-zinc-400 hover:text-brand-primary transition-colors">LinkedIn</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
